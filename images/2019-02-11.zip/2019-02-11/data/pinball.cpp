#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int MAXN=500000+10;
const LL INF=100000000000000000000LL;
int n,m,cnt,a[MAXN],b[MAXN],c[MAXN],d[MAXN],v[MAXN*3],h[MAXN*3];
LL ans=INF,l[MAXN],r[MAXN],t[MAXN*10],tag[MAXN*10];
inline int Read()
{
	int x=0; char ch=getchar();
	while (ch<'0'||ch>'9') {ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<3)+(x<<1)+ch-'0'; ch=getchar();}
	return x;
}
inline int find(int x)
{
	int l=1,r=cnt,mid;
	while (l<=r)
	{
		mid=(l+r)>>1;
		if (h[mid]==x) return mid;
		if (x>h[mid]) l=mid+1; else r=mid-1;
	}
}
void build(int x,int l,int r)
{
	t[x]=INF;
	tag[x]=0;
	if (l==r) return; 
	else 
	{
		int mid=(l+r)>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
	}
}
void pushdown(int x)
{
	if (tag[x])
	{
		t[x<<1]=min(t[x<<1],tag[x]);
		if (tag[x<<1]) tag[x<<1]=min(tag[x<<1],tag[x]); else tag[x<<1]=tag[x];
		t[x<<1|1]=min(t[x<<1|1],tag[x]);
		if (tag[x<<1|1]) tag[x<<1|1]=min(tag[x<<1|1],tag[x]); else tag[x<<1|1]=tag[x];
		tag[x]=0;
	}
}
LL work(int x,int l,int r,int k)
{
	if (l!=r) pushdown(x);
	if (l==k&&r==k) return t[x];
	int mid=(l+r)>>1;
	if (k<=mid) return work(x<<1,l,mid,k); else work(x<<1|1,mid+1,r,k);
}
void insert(int x,int l,int r,int p,int q,LL val)
{
	if (l!=r) pushdown(x);
	if (p<=l&&r<=q)
	{
		t[x]=min(t[x],val);
		tag[x]=val;
		return;
	}
	int mid=(l+r)>>1;
	if (p<=mid) insert(x<<1,l,mid,p,q,val); 
	if (q>mid) insert(x<<1|1,mid+1,r,p,q,val);
	t[x]=min(t[x<<1],t[x<<1|1]);
}
int main()
{
//	freopen("pinball10.in","r",stdin);
//    freopen("pinball10.out","w",stdout);
	n=Read(),m=Read();
	for (int i=1;i<=n;++i) 
	{
		a[i]=Read(),b[i]=Read(),c[i]=Read(),d[i]=Read();
		if (a[i]==1) l[i]=d[i]; else l[i]=INF;
		if (b[i]==m) r[i]=d[i]; else r[i]=INF;
		v[(i-1)*3+1]=a[i];
		v[(i-1)*3+2]=b[i];
		v[(i-1)*3+3]=c[i];
	}
	sort(v+1,v+n*3+1);
	h[cnt=1]=v[1];
	for (int i=1;i<=n*3;++i) if (v[i]!=h[cnt]) h[++cnt]=v[i];
	for (int i=1;i<=n;++i)
	{
		a[i]=find(a[i]);
		b[i]=find(b[i]);
		c[i]=find(c[i]);
	}
	build(1,1,cnt);
	for (int i=1;i<=n;++i)
	{
		l[i]=min(l[i],work(1,1,cnt,a[i])+d[i]);
		if (l[i]<INF&&a[i]<c[i]) insert(1,1,cnt,a[i]+1,c[i],l[i]);
	}
	build(1,1,cnt);
	for (int i=1;i<=n;++i)
	{
		r[i]=min(r[i],work(1,1,cnt,b[i])+d[i]);
		if (r[i]<INF&&c[i]<b[i]) insert(1,1,cnt,c[i],b[i]-1,r[i]);
		if (l[i]<INF&&r[i]<INF) ans=min(ans,l[i]+r[i]-d[i]);
	}
	if (ans<INF) cout<<ans<<endl; else puts("-1");
	return 0;
}
