#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int MaxN=1000000+10;
struct Edge{int to,next;} e[MaxN*2];
int n,cnt,sum,ans,x,y,first[MaxN],size[MaxN],num[MaxN];
inline void Add(int u,int v) {e[++cnt].to=v; e[cnt].next=first[u]; first[u]=cnt;}
inline int Read()
{
    int x=0,f=1; char ch=getchar(); 
    while (ch<'0'||ch>'9') {if (ch=='-') f=-f; ch=getchar();}
    while (ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
    return x*f;
}
void dfs(int u,int fa)
{
    size[u]=1;
    for (int i=first[u];i;i=e[i].next) if (e[i].to!=fa) {dfs(e[i].to,u), size[u]+=size[e[i].to];}
    ++num[size[u]];
}
int main()
{
    n=Read();
    for (int i=1;i<n;++i) x=Read(),y=Read(),Add(x,y),Add(y,x);
    dfs(1,0);
    for (int i=1;i<=n;++i) if (n%i==0)
    {
        sum=0;
        for (int j=i;j<=n;j+=i) sum+=num[j];
        if (sum==n/i) ++ans;
    }
    cout<<ans<<endl;
    return 0;
}