#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
const int MaxN=200000+10,MaxM=200000+10,MaxLog=18,INF=1000000000;
struct Heap_Node
{
    int d,u;
    bool operator < (const Heap_Node& a) const{return d>a.d;}
};
struct Edge{int from,to,cost,next;} e[MaxM*4];
int n,m,k,cnt,num,tot;
int c[MaxN],first[MaxN],dis[MaxN],from[MaxN],dep[MaxN],p[MaxN],belong[MaxN];
bool mark[MaxN];
int fa[MaxN][MaxLog+5],g[MaxN][MaxLog+5];
inline int Read()
{
    int x=0,f=1; char ch=getchar();
    while (ch<'0'||ch>'9') {if (ch=='-') f=-1; ch=getchar();}
    while (ch>='0'&&ch<='9') {x=x*10+ch-'0'; ch=getchar();}
    return x*f;
}
inline void Add(int u,int v,int w)
{
    e[++cnt].from=u; e[cnt].to=v; e[cnt].cost=w;
    e[cnt].next=first[u]; first[u]=cnt;
}
void Init()
{
    freopen("petrol.in","r",stdin);
    freopen("petrol.out","w",stdout);
    int x,y,z; 
    n=Read(); k=Read(); m=Read();
    for (int i=1;i<=k;++i) c[i]=Read();
    for (int i=1;i<=m;++i) {x=Read(); y=Read(); z=Read(); Add(x,y,z); Add(y,x,z);}
}
inline int max(int a,int b) {if (a>b) return a; else return b;}
inline bool cmp(Edge a,Edge b) {return a.cost<b.cost;}
priority_queue<Heap_Node> H;
void Dijkstra()
{
    for (int i=1;i<=n;++i) {dis[i]=INF; mark[i]=0;}
    for (int i=1;i<=k;++i) {dis[c[i]]=0; from[c[i]]=c[i]; H.push((Heap_Node){0,c[i]});}
    while (!H.empty())
    {
        Heap_Node x=H.top(); H.pop(); int u=x.u;
        if (mark[u]) continue; else mark[u]=1;
        for (int i=first[u];i;i=e[i].next)
        {
            int v=e[i].to;
            if (dis[u]+e[i].cost<dis[v]) 
            {
                dis[v]=dis[u]+e[i].cost; from[v]=from[u];
                H.push((Heap_Node){dis[v],v});
            }
        }
    }
}
void dfs(int u)
{
    for (int i=1;i<=MaxLog;++i) if (1<<i<=dep[u]) fa[u][i]=fa[fa[u][i-1]][i-1],g[u][i]=max(g[u][i-1],g[fa[u][i-1]][i-1]); else break;
     
    for (int i=first[u];i;i=e[i].next)
    {
        int v=e[i].to;
        if (v!=fa[u][0])
        {
            dep[v]=dep[u]+1; belong[v]=belong[u]; fa[v][0]=u; g[v][0]=e[i].cost; 
            dfs(v);
        }
    }
}
int find(int x) {if (p[x]!=x) p[x]=find(p[x]); return p[x];}
void Kruskal()
{
    int x,y,tot=cnt; cnt=0;
    for (int i=1;i<=n;++i) p[i]=i;
    sort(e+num+1,e+tot+1,cmp);
     
    memset(first,0,sizeof(first));
    for (int i=num+1;i<=tot;++i)
    {
        x=find(e[i].from); y=find(e[i].to);
        if (x!=y) {p[x]=y; Add(e[i].from,e[i].to,e[i].cost); Add(e[i].to,e[i].from,e[i].cost);}
    }
}
void prepare()
{
    Dijkstra(); 
     
    num=cnt; 
    for (int i=1;i<=num;i+=2) 
    {
        int u=e[i].from,v=e[i].to,w=e[i].cost;
        if (from[u]!=from[v]) e[++cnt]=(Edge){from[u],from[v],dis[u]+dis[v]+w,0};
    }
    Kruskal(); 
    for (int i=1;i<=k;++i) if (!belong[c[i]]) belong[c[i]]=++tot,dfs(c[i]);
}
inline int query(int x,int y)
{
   if (dep[x]<dep[y]) {int tmp=x; x=y; y=tmp;}
   int delta=dep[x]-dep[y],MaxC=0;
   for (int i=0;i<=MaxLog;++i) if ((1<<i)&delta) MaxC=max(MaxC,g[x][i]),x=fa[x][i];
 
   for (int i=MaxLog;i>=0;--i)
       if (fa[x][i]!=fa[y][i]) MaxC=max(MaxC,g[x][i]),MaxC=max(MaxC,g[y][i]),x=fa[x][i],y=fa[y][i]; 
   if (x!=y) MaxC=max(MaxC,g[x][0]),MaxC=max(MaxC,g[y][0]);
   return MaxC;
}
void Solve()
{   
    int Q=Read(),u,v,maxc;
    while (Q--)
    {
        u=Read(); v=Read(); maxc=Read();
        if (belong[u]!=belong[v]||query(u,v)>maxc) puts("NIE"); else puts("TAK");
    }
}
int main()
{
    Init();
    prepare();
    Solve();
    return 0;
}