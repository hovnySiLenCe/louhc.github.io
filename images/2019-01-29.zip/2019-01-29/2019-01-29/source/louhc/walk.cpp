#include<bits/stdc++.h>
using namespace std;
#define open(s) freopen( s".in", "r", stdin ), freopen( s".out", "w", stdout )
#define MAXN 400005

int N, n;

char bf[1 << 23], *p;

inline void read( int &x ){
	x = 0; for ( ; !isdigit(*p); ++p );
	for ( ; isdigit(*p); ++p ) x = x * 10 + ( (*p) & 15 );
}

struct _edge{
	int fr, to, nxt;
	_edge( int x = 0, int y = 0, int z = 0 ):fr(x), to(y), nxt(z){}
}_a[MAXN << 1];

int _hd[1000005], _tot;
int hd[MAXN], nxt[MAXN << 1], to[MAXN << 1], tot;
bool in[MAXN], vis[MAXN];
int s[MAXN], cnt, ans;
int f[MAXN];

inline void _add( int x, int y, int z ){ _a[++_tot] = _edge( x, y, _hd[z] ); _hd[z] = _tot; }
inline void add( int x, int y ){
	nxt[++tot] = hd[x]; hd[x] = tot; to[tot] = y; if ( !in[x] ) in[x] = 1, s[++cnt] = x;
	nxt[++tot] = hd[y]; hd[y] = tot; to[tot] = x; if ( !in[y] ) in[y] = 1, s[++cnt] = y;
}

int DFS( int x ){
	int res1(0), res2(0), t; vis[x] = 1;
	for ( int i = hd[x]; i; i = nxt[i] ) if ( !vis[to[i]] ){
		if ( vis[to[i]] ) continue;
		t = DFS( to[i] );
		if ( t >= res1 ) res2 = res1, res1 = t + 1;
		else if ( t >= res2 ) res2 = t + 1;
	}
	ans = max( ans, res2 + res1 ); return res1;
}

int main(){
	open("walk");
	bf[fread( bf, 1, 1 << 23, stdin )] = '\0'; p = bf;
	
	read(N); int x, y, z;
	for ( int i = 1; i < N; ++i ) read(x), read(y), read(z), _add( x, y, z ), n = max( n, z );
	for ( int i = 1; i <= n; ++i ){
		
		for ( int j = i; j <= n; j += i )
			for ( int k = _hd[j]; k; k = _a[k].nxt )
				add( _a[k].fr, _a[k].to );
		ans = 0;
		for ( int j = 1; j <= cnt; ++j ) if ( !vis[s[j]] ) DFS( s[j] );
		f[ans] = i;
		for ( int j = 1; j <= cnt; ++j ) in[s[j]] = 0, vis[s[j]] = 0, hd[s[j]] = 0;
		cnt = tot = 0;
	}
	for ( int i = N - 1; i >= 1; --i ) f[i] = max( f[i + 1], f[i] );
	for ( int i = 1; i <= N; ++i ) printf( "%d\n", f[i] );
	return 0;
}
