#include <cmath>
#include <cstdio>
#include <iostream>
using namespace std;
FILE *fscore,*freport,*fstd,*fin,*fout;

typedef long long LL;
const int maxn = 200005;
int x[maxn],n,l,s,vis[maxn];
int ABS(int x) {return x>0?x:-x;}
bool judge() {
	fscanf(fin,"%d %d %d",&n,&l,&s);
	for (int i=1;i<=n;i++)
		fscanf(fin,"%d",&x[i]);
	LL ans,user;
	fscanf(fstd,"%lld",&ans);
	fscanf(fout,"%lld",&user);
	if (ans!=user) return 0;
	if (ans==-1) return 1;
	int cur=s;LL sum=0;vis[cur]=1;
	for (int u,i=1;i<n;i++) {
		fscanf(fout,"%d",&u);
		if (u<1||u>n) return 0;
		if (vis[u]) return 0;vis[u]=true;
		if (u<cur) l--;sum+=ABS(x[u]-x[cur]);
		cur=u;
	}
	if (l!=0) return 0;
	if (sum!=ans) return 0;
	return 1;
}
int main(int argc,char *argv[])
{
	fscore=fopen(argv[5],"w");//�÷��ļ�
	freport=fopen(argv[6],"w");//�����ļ�
	fstd=fopen(argv[3],"r");//��׼���
	fin=fopen(argv[1],"r");//��׼����
	fout=fopen(argv[2],"r");//�û����
	fprintf(fscore,"%d",judge()*5);
	fclose(fscore);//�رյ÷��ļ�
	fclose(freport);//�رձ����ļ�
	return 0;
}
