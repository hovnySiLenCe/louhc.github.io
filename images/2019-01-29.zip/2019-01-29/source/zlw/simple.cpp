#pragma GCC optimize(3)
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<set>
#define ll long long
#define int ll
using namespace std;
inline int read(){
	int ans=0,f=1;char chr=getchar();
	while(!isdigit(chr)) {if(chr=='-')f=-1;chr=getchar();}
	while(isdigit(chr))  {ans=(ans<<3)+(ans<<1)+chr-'0';chr=getchar();}
	return ans*f;
}
ll T,n,m,q,i,ans,t,t0,t1,j;
set<ll> s;
signed main(){
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	T=read();
	while(T--){ans=0;t=0;s.clear();
		n=read(),m=read(),q=read();
		if(n>m) swap(n,m);
		t=q/m;
		for(register int i=0;i<=t;++i){
			t0=i*m;
			t1=q-t0;
			j=0;
			while((t=j*n)<=t1){
				if(t+t0<=q)
				s.insert(t0+j*n);
				j++;
			}
		}printf("%lld\n",q-s.size()+1);
	}
	return 0;
}
