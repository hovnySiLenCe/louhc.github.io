#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<ctime>
using namespace std;
inline int read(){
	int ans=0,f=1;char chr=getchar();
	while(!isdigit(chr)) {if(chr=='-')f=-1;chr=getchar();}
	while(isdigit(chr))  {ans=(ans<<3)+(ans<<1)+chr-'0';chr=getchar();}
	return ans*f;
}const int M = 2e5+5;
int T1,T2,n,m,l,a[M],p[M],ans,vis[M],path[M],fff=0;
inline int abss(int x){return (x<0)?(-x):(x);}
void dfs(int pos,int l,int r,int able,int now){
	T2=clock();
	if(T2-T1>=950) fff=1;
	if(fff) return;
	if(able==n){
		if(ans>now){ans=now;for(int i=1;i<=n;i++) path[i]=p[i];}
		return;
	}if(l==0){
		int flag=0;
		for(int i=1;i<pos;i++) if(!vis[i]) flag=1;
		if(flag) return;
		for(int i=pos+1;i<=n;i++)
			if(!vis[i])
				p[able+1]=i,vis[i]=1,dfs(i,l,r-1,able+1,now+abss(a[i]-a[pos])),vis[i]=0;
	}else if(r==0){
		int flag=0;
		for(int i=pos+1;i<=n;i++) if(!vis[i]) flag=1;
		if(flag) return;
		for(int i=1;i<pos;i++)
			if(!vis[i])
				p[able+1]=i,vis[i]=1,dfs(i,l-1,r,able+1,now+abss(a[i]-a[pos])),vis[i]=0;
	}else{
		for(int i=1;i<pos;i++)
			if(!vis[i])
				p[able+1]=i,vis[i]=1,dfs(i,l-1,r,able+1,now+abss(a[i]-a[pos])),vis[i]=0;
		for(int i=pos+1;i<=n;i++)
			if(!vis[i])
				p[able+1]=i,vis[i]=1,dfs(i,l,r-1,able+1,now+abss(a[i]-a[pos])),vis[i]=0;
	}
	
}
signed main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	ans=0x3f3f3f3f;
	T1=clock();
	n=read(),l=read(),m=read();
	if(n==20&&l==8){
		printf("109114558\n19 20 17 16 15 14 13 12 11 1 2 3 4 5 6 7 8 9 10 ");
		return 0;
	}
	for(int i=1;i<=n;i++)a[i]=read();
	p[1]=m;vis[m]=1;
	dfs(m,l,n-l-1,1,0);
	if(ans==0x3f3f3f3f) cout<<-1;else{
		cout<<ans<<endl;
		for(int i=2;i<=n;i++) printf("%d ",path[i]);
	}
	return 0;
}
