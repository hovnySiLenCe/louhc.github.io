#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
inline int read(){
	int ans=0,f=1;char chr=getchar();
	while(!isdigit(chr)) {if(chr=='-')f=-1;chr=getchar();}
	while(isdigit(chr))  {ans=(ans<<3)+(ans<<1)+chr-'0';chr=getchar();}
	return ans*f;
}
void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}
int main(){
	int n=read();
	write(n);
	return 0;
}

