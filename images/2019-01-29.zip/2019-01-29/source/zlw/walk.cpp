#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<queue>
#include<cstdlib>
#include<ctime>
using namespace std;
int T1,T2;
inline int read(){
	int ans=0,f=1;char chr=getchar();
	while(!isdigit(chr)) {if(chr=='-')f=-1;chr=getchar();}
	while(isdigit(chr))  {ans=(ans<<3)+(ans<<1)+chr-'0';chr=getchar();}
	return ans*f;
}
void write(int x){
	if(x>9) write(x/10);
	putchar(x%10+48);
}
const int M=4e5+4;
int head[M<<1],nxt[M<<1],ver[M<<1],val[M<<1],tot,n,m,x,y,z,ans[M],vis[M];
inline int add(int x,int y,int z){ver[++tot]=y;val[tot]=z;nxt[tot]=head[x];head[x]=tot;}
inline int gcd(int x,int y){if(y==0) return x;return gcd(y,x%y);}
inline int max(int x,int y){return x>y?x:y;}
inline int random(int x){return rand()%x+1;}
queue<int> q,d,g;
inline void BFS(int b){memset(vis,0,sizeof(vis));
	while(!q.empty()) q.pop();while(!d.empty()) d.pop();while(!g.empty()) g.pop();
	q.push(b),d.push(0),g.push(0);vis[b]=1;
	while(!q.empty()){
		int x=q.front(),y=d.front(),z=g.front();
		q.pop(),d.pop(),g.pop();
		for(int i=head[x];i;i=nxt[i]){
			int v=ver[i];if(vis[v]) continue;
			vis[v]=1;
			int tmp=gcd(z,val[i]);
			d.push(y+1),q.push(v),g.push(tmp);
			ans[y+1]=max(tmp,ans[y+1]);
		}
	}
}
inline void BFS1(int b){memset(vis,0,sizeof(vis));
	while(!q.empty()) q.pop();while(!d.empty()) d.pop();while(!g.empty()) g.pop();
	q.push(b),d.push(0),g.push(0);vis[b]=1;
	while(!q.empty()){
		int x=q.front(),y=d.front(),z=g.front();
		if(y>=100) return;
		q.pop(),d.pop(),g.pop();
		for(int i=head[x];i;i=nxt[i]){
			int v=ver[i];if(vis[v]) continue;
			vis[v]=1;
			int tmp=gcd(z,val[i]);
			d.push(y+1),q.push(v),g.push(tmp);
			ans[y+1]=max(tmp,ans[y+1]);
		}
	}
}
inline void Check1(){for(int i=1;i<=n;i++)BFS(i);}
int pp[M],ttt=0;
inline void Check2(){
	srand(unsigned(time(NULL)));
	for(register int i=1;i<=n;++i){srand(unsigned(time(NULL)));
		T2=clock();
		if(T2-T1>=825) return;
		int p=random(n);
		BFS1(p);
	}return;
}
int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	T1=clock();
	n=read();
	for(register int i=1;i<n;++i)x=read(),y=read(),z=read(),add(x,y,z),add(y,x,z);
	if(n<=10000) Check1();
	else Check2();
	for(register int i=1;i<=n;++i) write(ans[i]),puts("");
	return 0;
}
