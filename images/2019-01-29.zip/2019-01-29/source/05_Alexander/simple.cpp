#include<bits/stdc++.h>
using namespace std;
long long gcd(long long x,long long y){
	if(y==0) return x;
	return gcd(y,x%y);
}
long long work(long long n,long long m,long long k){
	long long ans=k+1;
	for(int a=0;a<=k/m;a++) ans-=(k-a*m)/n+1;
	return ans;
}
int main(){
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	int t;
	cin>>t;
	for(int i=1;i<=t;i++){
		long long n,m,q,ans,k;
		cin>>n>>m>>q;
		if(n>m) swap(n,m);
		if(n==m){
			cout<<0<<endl;
			continue;
		}
		k=n*m/gcd(n,m);
		if(q<k) cout<<work(n,m,q)<<endl;
		else cout<<(q/k)*work(n,m,k)+work(n,m,q%k)<<endl;
	}
	return 0;
}
