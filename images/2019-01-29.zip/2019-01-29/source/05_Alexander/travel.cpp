#include<bits/stdc++.h>
using namespace std;
struct ar{
	int el[2005];
}min_step;
int n,l,s,a[2005],minn=0x7fffffff;
bool fg[2005];
void work(int sta,int lef,int cos,ar step,int p){
	if(cos>=minn) return;
	if(p==n) minn=cos,min_step=step;
	for(int i=1;i<=n;i++)
		if(!fg[i]){
			fg[i]=1,step.el[p+1]=i;
			if(i<sta&&lef) work(i,lef-1,cos+abs(a[i]-a[sta]),step,p+1);
			else work(i,lef,cos+abs(a[i]-a[sta]),step,p+1);
			fg[i]=0;
		}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>l>>s;
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	fg[s]=1,work(s,l,0,min_step,1);
	cout<<minn<<endl;
	for(int i=2;i<n;i++)
		printf("%d ",min_step.el[i]);
	cout<<min_step.el[n]<<endl;
	return 0;
}
