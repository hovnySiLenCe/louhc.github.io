#include <bits/stdc++.h>
using namespace std;
struct Edge {
	int u,v,w;
}edge[800002];
int n;
int maxn[400001];
bool mark[800001];
int gcd(int a,int b) {
	if(b==0)
	    return a;
	return gcd(b,a%b);
}
void DFS(int x,int g,int len) {
	if(len>n)
	  return;
	maxn[len]=max(g,maxn[len]);
	for(int i=1;i<=2*n-2;i++)
	    if(edge[i].u==x&&!mark[i]) {
	    	mark[i]=mark[((i>n-1)?(i-(n-1)):(i+n-1))]=1;
	    	DFS(edge[i].v,gcd(g,edge[i].w),len+1);
	    	mark[i]=mark[((i>n-1)?(i-(n-1)):(i+n-1))]=1;
		}
}
int main() {
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;i++)
	    cin>>edge[i].u>>edge[i].v>>edge[i].w;
	for(int i=n;i<2*n-1;i++)
	    edge[i].u=edge[i-(n-1)].v,edge[i].v=edge[i-(n-1)].u,edge[i].w=edge[i-(n-1)].w;
	for(int i=1;i<=n;i++) {
		memset(mark,0,sizeof(mark));
		DFS(i,0,0);
	}
	for(int i=1;i<=n;i++)
		printf("%d\n",maxn[i]);
	return 0;
}
