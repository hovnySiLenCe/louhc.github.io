#include <bits/stdc++.h>
using namespace std;
long long n,m,q;
long long good[111111];
int cas,cnt,ans;
int main() {
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	scanf("%d",&cas);
	while(cas--) {
		scanf("%d%d%d",&n,&m,&q);
		memset(good,0,sizeof(good));
		ans=cnt=0;
		for(int i=1;i<=q;i++) {
			bool flag=1;
			for(int j=1;j<=cnt;j++)
			    if(i%good[j]==0) {
			    	flag=0;
			    	break;
				}
			if(flag) {
				for(int j=0;i-n*j>=0;j++)
				    if((i-n*j)%m==0) {
				    	flag=0;
				    	good[++cnt]=i;
				    	break;
					}
			}
			if(flag)
			    ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
