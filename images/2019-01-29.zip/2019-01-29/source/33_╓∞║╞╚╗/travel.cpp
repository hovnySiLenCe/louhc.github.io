#include <bits/stdc++.h>
using namespace std;
int main() {	
    freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	printf("-1");
	return 0;
}
