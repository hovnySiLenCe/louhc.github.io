#include<bits/stdc++.h>
using namespace std;
#define open(s) freopen( s".in", "r", stdin ), freopen( s".out", "w", stdout )
#define LL long long

int T;
LL N, M, Q;

LL gcd( LL x, LL y ){ return y ? gcd( y, x % y ) : x; }

inline LL solve(){
	LL t(N / gcd( N, M )), ans(0);
	for ( LL i = 0; i < t; ++i )
		if ( Q >= i * M ) ans += ( Q - i * M ) / N + ( i != 0 );
		else break;
	return Q - ans;
}

int main(){
	open("simple");
	scanf( "%d", &T );
	while( T-- ){
		scanf( "%lld%lld%lld", &N, &M, &Q );
		printf( "%lld\n", solve() );
	}
	return 0;
}
