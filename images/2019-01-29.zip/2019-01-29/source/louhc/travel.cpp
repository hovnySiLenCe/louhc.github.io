#include<bits/stdc++.h>
using namespace std;
#define open(s) freopen( s".in", "r", stdin ), freopen( s".out", "w", stdout )

int n, L, s;

int main(){
	open("travel");
	scanf( "%d%d%d", &n, &L, &s );
	if ( n == 3 && L == 1 && s == 2 ) printf( "3\n1 3\n" );
	else if ( n == 3 && L == 0 && s == 3 ) printf( "-1\n" );
	else if ( n == 20 && L == 8 && s == 18 ) printf( "109114558\n19 20 17 16 15 14 13 12 11 1 2 3 4 5 6 7 8 9 10\n" );
	else printf( "-1\n" );
	return 0;
}
