//by Judge
#include<bits/stdc++.h>
#pragma GCC optimize(3)
using namespace std;
const int M=4e5+5;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
char buf[1<<20],*p1,*p2;
inline void cmax(int& a,int b){if(a<b)a=b;}
inline int read(){ int x=0,f=1; char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0'; return x*f;
} int n,pat,head[M],ans[M];
struct Edge{ int to,val,next; }e[M<<1];
inline void add(int x,int y,int z){
	e[++pat]=(Edge){y,z,head[x]},head[x]=pat;
	e[++pat]=(Edge){x,z,head[y]},head[y]=pat;
}
int GCD(int x,int y){
	return y?GCD(y,x%y):x;
}
#define v e[i].to
void dfs(int u,int fa,int du,int gcd){
	cmax(ans[du],gcd);
	for(int i=head[u];i;i=e[i].next)if(v^fa)
		dfs(v,u,du+1,GCD(gcd,e[i].val));
}
int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	n=read();
	for(int i=1,x,y,z;i<n;++i)
		x=read(),y=read(),z=read(),
		add(x,y,z),add(y,x,z);
	for(int i=1;i<=n;++i)
		dfs(i,0,0,0);
	for(int i=1;i<=n;++i)
		printf("%d\n",ans[i]);
	return 0;
}
