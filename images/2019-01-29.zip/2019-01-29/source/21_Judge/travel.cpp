//by Judge
#include<bits/stdc++.h>
using namespace std;
const int M=2e5+5;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
char buf[1<<20],*p1,*p2;
inline int read(){ int x=0,f=1; char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0'; return x*f;
} int n,L,R,s,ans,x[M];
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read(),L=read(),R=n-L-1,s=read();
	for(int i=1;i<=n;++i) x[i]=read();
	if((s<n&&!R) || (s>1&&!L))
		return puts("-1"),0;
	ans=x[n]-x[1];
	if(L>=s-1){
		if(x[s]-x[1]>x[s+R]-x[s]){
			ans+=x[n]-x[s];
			printf("%d\n",ans);
			for(int i=1;i<R;++i)
				printf("%d ",s+i);
			for(int i=n;i>=s+R;--i)
				printf("%d ",i);
			for(int i=s-1;i>=1;--i)
				printf("%d ",i);
		}
		else {
			ans+=x[s]-x[1]+x[n]-x[s+R];
			printf("%d\n",ans);
			for(int i=s-1;i>=1;--i)
				printf("%d ",i);
			for(int i=1;i<R;++i)
				printf("%d ",s+i);
			for(int i=n;i>=s+R;--i)
				printf("%d ",i);
		}
	} else{
		if(x[n]-x[s]>x[s]-x[s-L]){
			ans+=x[s]-x[1];
			printf("%d\n",ans);
			for(int i=1;i<L;++i)
				printf("%d ",s-i);
			for(int i=1;i<=s-L;++i)
				printf("%d ",i);
			for(int i=s+1;i<=n;++i)
				printf("%d ",i);
		}
		else {
			ans+=x[n]-x[s]+x[s-L]-x[1];
			printf("%d\n",ans);
			for(int i=s+1;i<=n;++i)
				printf("%d ",i);
			for(int i=1;i<L;++i)
				printf("%d ",s-i);
			for(int i=1;i<=s-L;++i)
				printf("%d ",i);
		}
	}
	return 0;
}
