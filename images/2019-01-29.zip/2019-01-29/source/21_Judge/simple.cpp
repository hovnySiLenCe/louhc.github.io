//by Judge
#include<bits/stdc++.h>
using namespace std;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
char buf[1<<20],*p1,*p2;
inline int read(){ int x=0,f=1; char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-'0'; return x*f;
} int a,b,q,x,y,d,X,Y,ans;
inline int exgcd(int a,int b,int& x,int& y){
	if(!b) return x=1,y=0,a;
	int d=exgcd(b,a%b,y,x); y-=a/b*x; return d;
}
int main(){
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	for(int T=read();T;--T){
		ans=0,a=read(),b=read(),q=read();
		d=exgcd(a,b,x,y),a/=d,b/=d;
		for(int i=1,tmp;i<=q;++i){
			if(i%d) {++ans;continue;}
			tmp=i/d,X=x*tmp,Y=y*tmp;
			Y+=X/b*a,X%=b;
			if(X<0) X+=b,Y-=a;
			if(Y<0) ++ans;
		} printf("%d\n",ans);
	} return 0;
}
