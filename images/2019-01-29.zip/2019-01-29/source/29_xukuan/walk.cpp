#pragma GCC optimize(2)
#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#define ll long long
#define INF 2147483647
using namespace std;

ll ver[800010],edge[800010],Next[800010],head[800010],tot;
ll vis[800010],Max,ans,n;

ll gcd(ll x,ll y){
	return x%y==0?y:gcd(y,x%y);
}

inline void addEdge(ll x,ll y,ll z){
	ver[++tot]=y;
	edge[tot]=z;
	Next[tot]=head[x];
	head[x]=tot;
}

inline void dfs(ll x,ll y,ll GCD){
	vis[x]=true;
	if(y==0){
		Max=max(Max,GCD);
		return;
	}
	for(ll i=head[x]; i; i=Next[i]){
		ll Next=ver[i];
		if(vis[Next]) continue;
		if(GCD==INF) dfs(Next,y-1,edge[i]);
		else dfs(Next,y-1,gcd(edge[i],GCD));
	}
}

int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1; i<n; i++){
		ll x,y,z;
		scanf("%lld %lld %lld",&x,&y,&z);
		addEdge(x,y,z);
		addEdge(y,x,z);
	}
	
	bool bo=true;
	for(ll i=1; i<=n; i++){
		ans=0;
		if(bo)
		for(ll j=1; j<=n; j++){
			memset(vis,0,sizeof(vis));
			Max=0;
			dfs(j,i,INF);
			ans=max(ans,Max);
		}
		printf("%lld\n",ans);
		if(ans==0) bo=false;
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
