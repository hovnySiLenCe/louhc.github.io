#pragma GCC optimize(2)
#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;

ll t;
bool b[10000010];

int main(){
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		ll n,m,q;
		scanf("%lld %lld %lld",&n,&m,&q);
		memset(b,false,sizeof(b));
		for(ll x=0; n*x<=q; x++){
			for(ll y=0; n*x+m*y<=q; y++){
				b[n*x+m*y]=true;
			}
		}
		
		ll ans=0;
		for(ll i=1; i<=q; i++){
			if(b[i]==false) ans++;
		}
		printf("%lld\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
