#include<bits/stdc++.h>
#define FILE(s) freopen(s".in","r",stdin);freopen(s".out","w",stdout);
using namespace std;
int read() {
	int x(0),f(0);
	char ch(0);
	while(!isdigit(ch))f|=(ch=='-'),ch=getchar();
	while(isdigit(ch))x=(x*10)+(ch^48),ch=getchar();
	return f?-x:x;
}
int head[400005];
int tot,n;
struct Edge {
	int to;
	int nxt;
	int w;
} edge[800005];
void addedge(int a,int b,int c) {
	edge[++tot]=(Edge) {
		b,head[a],c
	};
	head[a]=tot;
}
struct node {
	int x;
	int dis;
};
bool mark[400005];
int bfs(int x,int &p) {
	memset(mark,0,sizeof(mark));
	queue<node>que;
	que.push((node) {
		x,0
	});
	node h;
	mark[x]=1;
	while(!que.empty()) {
		h=que.front();
		que.pop();
		//printf("%d;%d\n",h.x,h.dis);
		for(int i=head[h.x]; i; i=edge[i].nxt)
			if(!mark[edge[i].to]) {
				mark[edge[i].to]=1;
				que.push((node) {
					edge[i].to,h.dis+1
				});
			}
	}
	p=h.x;
	return h.dis;
}
int gcd(int a,int b) {
	return !b?a:gcd(b,a%b);
}
int limit;
int ans[400005];
void dfs(int h,int x,int fa,int sum) {
	if(h>limit)return;
	ans[h]=max(ans[h],sum);
	for(int i=head[x]; i; i=edge[i].nxt)
		if(edge[i].to!=fa)
			dfs(h+1,edge[i].to,x,gcd(sum,edge[i].w));
}
int main() {
	//freopen("walk.in","r",stdin);
	FILE("walk")
	n=read();
	for(int i=1; i<n; i++) {
		int u=read(),v=read(),w=read();
		addedge(u,v,w);
		addedge(v,u,w);
	}
	int p;
	int d=bfs(1,p);
	d=bfs(p,p);
	//printf("%d\n",d);
	if(n>=20) {
		for(limit=5; limit<=d+1; limit=min(limit+5,d+1)) {
			//printf("limit=%d\n",limit);
			for(int i=1; i<=n; i++)
				dfs(1,i,-1,0);
			if(ans[limit]==1)break;
		}
		for(int i=1; i<limit; i++)
			printf("%d\n",ans[i+1]);
		for(int i=limit; i<=d; i++)
			printf("1\n");
		for(int i=d+1; i<=n; i++)
			printf("0\n");
	} else {
		limit=n;
		for(int i=1; i<=n; i++)
			dfs(1,i,-1,0);
		for(int i=1;i<=limit;i++)
		printf("%d\n",ans[i+1]);
	}
	return 0;
}
