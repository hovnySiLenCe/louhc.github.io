#include<bits/stdc++.h>
#define FILE(s) freopen(s".in","r",stdin);freopen(s".out","w",stdout);
using namespace std;
int main()
{
	FILE("travel");
	printf("-1\n");
	return 0;
}
