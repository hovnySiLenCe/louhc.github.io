#include<bits/stdc++.h>
#define FILE(s) freopen(s".in","r",stdin);freopen(s".out","w",stdout);
#define LL long long
using namespace std;
LL n,m;
LL q;
LL t;
LL gcd(LL a,LL b) {
	return !b?a:gcd(b,a%b);
}
int main() {
	FILE("simple")
	scanf("%lld",&t);
	while(t--) {
		scanf("%lld%lld%lld",&n,&m,&q);
		//--���в���--
		if(n>q) {
			printf("%lld\n",q-q/m);
			continue;
		}
		if(m>q) {
			printf("%lld\n",q-q/n);
			continue;
		}
		// -----------
		LL lcm=n*m/gcd(n,m);
		LL big=max(n,m);
		LL sma=min(n,m);
		LL ans=q-q/sma;
		LL g=big;
		while(g!=lcm)
		{
			if(q<g)break;
			//printf("-->%lld;",g);
			ans-=(q-g)/sma+1;
			//printf("ans-=%lld;ans=%lld\n",(q-g)/sma+1,ans);
			g+=big;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
