#include<bits/stdc++.h>
using namespace std;
long long n,m,q;
int main() {
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--) {
		scanf("%lld%lld%lld",&n,&m,&q);
		long long ans=0,x=max(n,m),a=q/x,y=min(n,m);
		if(x%y==0) cout<<q-q/y<<endl;
		else {
			for(int i=0; i<=a; i++)
			if(i*x<=q) ans+=(long long)((q-i*x)/y);
			ans+=a+1;
			printf("%lld\n",q-ans+1);
		}
	}
	return 0;
}
