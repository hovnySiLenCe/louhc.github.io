#include<bits/stdc++.h>
using namespace std;
const int maxn=4e5+10;
int n,ans[maxn],head[maxn],cnt;
bool vis[maxn];
struct node{
	int nxt,to,w;
}edge[maxn<<1];
void add_edge(int x,int y,int w){
	edge[++cnt]=(node){head[x],y,w};
	head[x]=cnt;
}
int GCD(int a,int b){
	if(b==0) return a;
	else return GCD(b,a%b);
}
void dfs(int x,int len,int a){
	ans[len]=max(ans[len],a);
	for(int i=head[x];i;i=edge[i].nxt){
		int y=edge[i].to;
		if(!vis[y]){
			vis[y]=1;
			if(len==0) dfs(y,len+1,edge[i].w);
			else dfs(y,len+1,GCD(edge[i].w,a));
		}
	}
}
int main(){
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	scanf("%d",&n);
	int x,y,w;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&x,&y,&w);
		add_edge(x,y,w),add_edge(y,x,w);
	}
	for(int i=1;i<=n;i++){
		memset(vis,0,sizeof(vis));
	    vis[i]=1,dfs(i,0,0);
	}
	for(int i=1;i<=n;i++) printf("%d\n",ans[i]);
	return 0;
}
