#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+10;
int n,l,r,s,a[maxn],p[maxn],b[maxn];
long long ans=1<<30;
bool vis[maxn];
void dfs(int x,int lstep,int rstep,long long cost){
	if(cost>ans) return;
	if(lstep==l&&rstep==r){
		if(ans>cost){
			ans=cost;
			for(int i=1;i<=n;i++) b[i]=p[i];
		}
		return;
	}
	if(lstep>l||rstep>r) return;
	for(int i=1;i<=n;i++)
	if(!vis[i]){
		vis[i]=1; p[x]=i;
		if(i<x) dfs(i,lstep+1,rstep,cost+abs(a[i]-a[x]));
		else dfs(i,lstep,rstep+1,cost+abs(a[i]-a[x]));
		vis[i]=0; p[x]=0;
	}
}
void print(int x){
	if(x==0) return;
	printf("%d ",x);
	print(b[x]);
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d%d",&n,&l,&s); r=n-l-1;
	for(int i=1;i<=n;i++) scanf("%d",a+i);
	if (n>20){
		printf("-1\n");
		return 0;
	}
	vis[s]=1,dfs(s,0,0,0);
	if(ans==1<<30) printf("-1\n");
	else {
		printf("%lld\n",ans);
		print(b[s]);
	}
	return 0;
}
