#include<bits/stdc++.h>
#define MAXN 400005
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
using namespace std;
int cnt,fst[MAXN],nxt[MAXN<<1],to[MAXN<<1];
int ecnt,efst[MAXN],enxt[MAXN],eto[MAXN];
int n,maxlen,dfn[MAXN],fr[MAXN],uu[MAXN<<1],ans[MAXN],Index;
template <typename T> void Read(T &x)
{
	register int fu=1;
	x=0;
	char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') fu=-1;
	for(;isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+(ch-48);
	x*=fu;
}
inline void AddEdge(register int u,register int v)
{
	to[++cnt]=v;
	nxt[cnt]=fst[u];
	fst[u]=cnt;
	uu[cnt]=u;
}
inline void EAddEdge(register int u,register int v,register int c)
{
	eto[++ecnt]=v;
	enxt[ecnt]=efst[c];
	efst[c]=ecnt;
	fr[ecnt]=u;
}
int Dfs(register int u)
{
	dfn[u]=Index;
	register int son=0;
	for(register int i=fst[u];i;i=nxt[i])
	{
		register int v=to[i];
		if(dfn[v]==Index) continue;
		register int d=Dfs(v);
		maxlen=max(maxlen,son+d+1);
		son=max(son,d+1);
	}
	return son;
}
int main()
{
	freopen("walk.in","r",stdin);
	freopen("walk.out","w",stdout);
	register int maxn=0;
	Read(n);
	for(register int i=1;i<n;i++)
	{
		register int x,y,z;
		Read(x);
		Read(y);
		Read(z);
		EAddEdge(x,y,z);
		maxn=max(maxn,z);
	}
	for(register int len=1;len<=maxn;len++)
	{
		cnt=0;
		memset(fst,0,sizeof(fst));
		for(register int i=len;i<=maxn;i+=len)
		{
			for(register int j=efst[i];j;j=enxt[j])
			{
				AddEdge(fr[j],eto[j]);
				AddEdge(eto[j],fr[j]);
			}
		}
		Index++;
		maxlen=0;
		for(register int i=1;i<=cnt;i++) if(dfn[uu[i]]!=Index) Dfs(uu[i]);
		ans[maxlen]=len;
	}
	for(register int i=n-1;i>=1;i--) ans[i]=max(ans[i],ans[i+1]);
	for(register int i=1;i<=n;i++) printf("%d\n",ans[i]);
	return 0;
}
