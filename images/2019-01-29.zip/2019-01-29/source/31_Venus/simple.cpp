#include<bits/stdc++.h>
#define MAXN 100005
#define ll long long
#define getchar() (p1==p2 && (p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
char buf[1<<21],*p1=buf,*p2=buf;
using namespace std;
ll n,m,q,f[MAXN];
template <typename T> void Read(T &x)
{
	register int fu=1;
	x=0;
	char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) if(ch=='-') fu=-1;
	for(;isdigit(ch);ch=getchar()) x=(x<<3)+(x<<1)+(ch-48);
	x*=fu;
}
int main()
{
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	register int Time;
	Read(Time);
	while(Time--)
	{
		memset(f,-1,sizeof(f));
		Read(n);
		Read(m);
		Read(q);
		f[0]=0;
		register ll pre=0,ans=0;
		while(!~f[(pre+m)%n])
		{
			f[(pre+m)%n]=f[pre]+m;
			pre=(pre+m)%n;
		}
		for(register int i=0;i<n;i++) if(~f[i] && f[i]<=q) ans+=(q-f[i])/n+1;
		ans=q-ans+1;
		printf("%lld\n",ans);
	}
	return 0;
}
