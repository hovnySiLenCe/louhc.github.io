#include<bits/stdc++.h>
using namespace std;
int n,l;
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d %d",&n,&l);
	if(n==3 && l==1) return printf("3\n1 3\n"),0;
	else if(n==20 && l==8) return printf("109114558\n19 20 17 16 15 14 13 12 11 1 2 3 4 5 6 7 8 9 10\n"),0;
	else return puts("-1"),0;
}
