#include<bits/stdc++.h>
using namespace std;

inline int read() {
	int W = 0, X = 0;
	char ch = 0;
	while (!isdigit(ch)) W |= ch == '-', ch = getchar();
	while (isdigit(ch)) X = (X << 3) + (X << 1) + (ch ^ 48), ch = getchar();
	return W ? -X : X;
}

inline void print(int x) {
	if (x >= 10) print(x / 10);
	putchar(x % 10 + 48);
}

inline void write(int x) {
	print(x), putchar('\n');
}

int n;
int to[400005], nxt[400005], hd[400005], tot;
int weigh[400005], dis[400005];

void add(int u, int v, int w) {
	to[++tot] = v, nxt[tot] = hd[u], hd[u] = tot, weigh[tot] = w;
}

int gcd(int a, int b) {
	if (a < b) swap(a, b);
	int tmp;
	while (b) {
		tmp = a % b;
		a = b;
		b = tmp;
	}
	return a;
}

void len(int fr, int go, int d, int num, int range) {
	int now;
	if (range) now = gcd(range, weigh[num]);
	else now = weigh[num];
	dis[d] = max(dis[d], now);
	for (int i = hd[go]; i; i = nxt[i])
		if (to[i] != fr) len(go, to[i], d + 1, i, now);
}

int main() {
	freopen("ex_walk2.in", "r", stdin);
	freopen("walk.out", "w", stdout);
	n = read();
	int u, v, w;
	for (int i = 1; i < n; ++i) {
		u = read(), v = read(), w = read();
		add(u, v, w), len(u, v, 1, tot, 0);
		add(v, u, w), len(v, u, 1, tot, 0);
	}
	for (int i = 1; i <= n; ++i)
		write(dis[i]);
	return 0;
} // Coded by Yukhoi
