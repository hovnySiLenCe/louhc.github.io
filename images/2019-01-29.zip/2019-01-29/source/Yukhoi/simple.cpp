#include<bits/stdc++.h>
using namespace std;
typedef long long LL;

inline LL read() {
	LL W = 0, X = 0;
	char ch = 0;
	while (!isdigit(ch)) W |= ch == '-', ch = getchar();
	while (isdigit(ch)) X = (X << 3) + (X << 1) + (ch ^ 48), ch = getchar();
	return W ? -X : X;
}

inline void print(LL x) {
	if (x >= 10) print(x / 10);
	putchar(x % 10 + 48);
}

inline void write(LL x) {
	print(x), putchar('\n');
}

LL T, n, m, q, cnt;
map<LL, bool> vis;

int main() {
	freopen("simple.in", "r", stdin);
	freopen("simple.out", "w", stdout);
	T = read();
	while (T--) {
		n = read(), m = read(), q = read(), cnt = 0;
		for (int i = 1; i <= q; ++i)
			vis[i] = 0;
		for (int x = 0; x * n <= q; ++x)
			for (int y = 0; x * n + y * m <= q; ++y)
				vis[x * n + y * m] = 1;
		for (int i = 1; i <= q; ++i)
			if (!vis[i]) ++cnt;
		write(cnt);
	}
	return 0;
} // Coded by Yukhoi
