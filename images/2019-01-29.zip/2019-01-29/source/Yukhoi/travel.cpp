#include<bits/stdc++.h>
using namespace std;

int main() {
	freopen("travel.in", "r", stdin), freopen("travel.out", "w", stdout);
	puts("-1");
	return 0;
} // Coded by Yukhoi
