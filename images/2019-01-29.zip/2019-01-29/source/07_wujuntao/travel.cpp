#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,l,s,f[200001],x[200001];
int vis[200001],ans=1e9;
bool pd()
{
	for(int i=1;i<=n;i++)
	  if(vis[i]==0) return false;
	  return true;
}
void dfs(int now,int left,int right,int sum)
{
	if(left==l) 
	{
		if(vis[1]==0) return ;
	}
	if(right==n-l-1) 
	{
		if(vis[n]==0) return ;
	}
	if(sum>=ans)  return ;
	if(ans>sum&&pd())
	{
		ans=sum;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++)
		  f[vis[i]]=i;
		return ;  
	}
	if(left<l)
	{
		for(int i=1;i<now;i++)
        {
        	if(vis[i]==0) 
        	{
        		vis[i]=left+right+2;
        		dfs(i,left+1,right,sum+abs(x[now]-x[i]));
        		vis[i]=0;
			}
		}
		}
	if(right<n-l-1)
	{
		for(int i=now+1;i<=n;i++)
       {
	    if(vis[i]==0)
	    {
	    	vis[i]=left+right+2;
	    	dfs(i,left,right+1,sum+abs(x[now]-x[i]));
	    	vis[i]=0;
		}
		}		}	
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>l>>s;
	for(int i=1;i<=n;i++) cin>>x[i];
	vis[s]=1;
	if(l>=n||l<=0) 
	{
		cout<<-1<<endl;
	}
 	else {	
	 dfs(s,0,0,0);
	 cout<<ans<<endl;
	 for(int i=2;i<=n;i++)
	   cout<<f[i]<<" ";
	 }
}
