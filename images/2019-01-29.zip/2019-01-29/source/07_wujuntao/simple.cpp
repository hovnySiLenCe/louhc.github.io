#include<iostream>
#include<cstdio>
#include<map>
#include<cstring>
using namespace std;
int n,m,t;
long long q,ans;
map<long long,int>f;
int main()
{
	freopen("simple.in","r",stdin);
	freopen("simple.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		ans=0;
		scanf("%d%d%lld",&n,&m,&q);
		for(int i=0;i<=q;i++) f[i]=0;
		for(int x=0;n*x<=q;x++)
		{
		  for(int y=0;n*x+m*y<=q;y++){
		  	
		  	if(f[n*x+m*y]==0) 
		  	{
		  		f[n*x+m*y]=1;
		  		ans++;
			  }
		  }
		
		 } 
		 printf("%lld\n",q-ans+1);
	}
	return 0;
}
